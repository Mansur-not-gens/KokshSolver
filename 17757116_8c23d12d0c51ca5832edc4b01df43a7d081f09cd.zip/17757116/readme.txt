Published on Tilda.cc
- - -
Upload the project to your website:
1. Copy the contents of this folder to your server by FTP
2. Rename file htaccess to .htaccess
